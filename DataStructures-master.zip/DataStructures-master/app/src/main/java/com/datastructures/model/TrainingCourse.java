package com.datastructures.model;

import lombok.Data;

/**
 * Учебный курс
 */
@Data
public class TrainingCourse {
}

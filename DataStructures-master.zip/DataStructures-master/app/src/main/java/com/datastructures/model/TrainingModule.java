package com.datastructures.model;

/**
 * Учебный модуль курса
 */
public class TrainingModule {
}

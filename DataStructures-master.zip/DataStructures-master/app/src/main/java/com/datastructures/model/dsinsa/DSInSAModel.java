package com.datastructures.model.dsinsa;

public interface DSInSAModel {
}

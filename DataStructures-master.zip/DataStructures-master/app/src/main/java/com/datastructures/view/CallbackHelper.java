package com.datastructures.view;


public interface CallbackHelper<T> {
    public void callback(T data) throws Exception;
}

package com.datastructures.view.courses.ds_in_sa;

import com.datastructures.view.CommonView;

/**
 * Интерфейс для взаимодействия активности и презентера при работе с курсом
 * "Структуры данных в системной аналитике"
 */
public interface CourseDSInSAView extends CommonView {
}

package com.datastructures.view.training;

/**
 * Интерфейс для взаимодействия между активностью и презентером при работе с учебными курсами приложения
 */
public interface TrainingView {
    public void transferToCourseDSInSA();
}
